export const metadata = {
  title: "AmzymDrive - Fast & Reliable Delivery",
  description:
    "Your trusted partner for quick, safe, and efficient delivery of food and goods.",
};
